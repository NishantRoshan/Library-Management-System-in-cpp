# Library-Management-System-in-C++
CS253 assignment
The project has been implemented using C++ language. To store the data of books and user, no new CSV or txt file was user. Rather the data was stored internally in the program using vectors and maps. Deletion, addition and updation is done on those vectors and maps itself.
To run the code, just execute the program on any compiler and follow the instructions on the terminal. 